function [X_out,P_out]=CKF(X_in,P_in,Z_in,R_in,trace_in)
global targetNum;
Q=0.05*eye(4);
T=1;
w=-3*pi/180;
F= [1  0 sin(w*T)/w -(1-cos(w*T))/w
    0 1 (1-cos(w*T))/w -sin(w*T)/w
    0 0 cos(w*T)    -sin(w*T)
    0  0 sin(w*T)  cos(w*T) ]; %

square_P=(chol(P_in))';
n=4;
yita=zeros(n*targetNum,2*n);
for i=1:n
    element=zeros(n*targetNum,1);
    for j=1:targetNum
    element(i+(j-1)*4)=1;
    end
    yita(:,i)=sqrt(n)*element;
end
for i=1:n
    element=zeros(n*targetNum,1);
    for j=1:targetNum
    element(i+(j-1)*4)=-1;
    end
    yita(:,i+n)=sqrt(n)*element;
end
X_in_sample=zeros(n*targetNum,2*n);
for i=1:2*n
    X_in_sample(:,i)=square_P*yita(:,i)+X_in;
end

%预测
X_pre_sample=zeros(n*targetNum,2*n);
for i=1:2*n
    X_pre_sample(:,i)=blkdiag(F,F,F)*X_in_sample(:,i);
end
sum=zeros(n*targetNum,1);
for i=1:2*n
    sum=sum+X_pre_sample(:,i);
end
X_pre=sum/(2*n);
sum=zeros(n*targetNum,n*targetNum);
for i=1:2*n
    sum=sum+X_pre_sample(:,i)*X_pre_sample(:,i)';
end
P_pre_pre=sum/(2*n)-X_pre*X_pre'+blkdiag(Q,Q,Q);
P_pre=blkdiag(P_pre_pre(1:4,1:4),P_pre_pre(5:8,5:8),P_pre_pre(9:12,9:12));


% %计算新的容积点
square_P=(chol(P_pre))';
n=4;

for i=1:2*n
    X_in_sample(:,i)=square_P*yita(:,i)+X_pre;
end
%观测部分
Z_pre_sample=zeros(2*targetNum,2*n);
for i=1:2*n
    for j=1:targetNum
    Z_pre_sample((j-1)*2+1:j*2,i)=measure(X_in_sample((j-1)*4+1:j*4,i),trace_in');
    end
end
sum=zeros(2*targetNum,1);
for i=1:2*n
    sum=sum+Z_pre_sample(:,i);
end
Z_pre=sum/(2*n);
sum=zeros(2*targetNum,2*targetNum);
for i=1:2*n
    sum=sum+Z_pre_sample(:,i)*Z_pre_sample(:,i)';
end
P_z_z_pre=sum/(2*n)-Z_pre*Z_pre'+blkdiag(R_in,R_in,R_in);
P_z_z=blkdiag(P_z_z_pre(1:2,1:2),P_z_z_pre(3:4,3:4),P_z_z_pre(5:6,5:6));

sum=zeros(n*targetNum,2*targetNum);
for i=1:2*n
    sum=sum+X_pre_sample(:,i)*Z_pre_sample(:,i)';
end
P_x_z_pre=sum/(2*n)-X_pre*Z_pre';
P_x_z=blkdiag(P_x_z_pre(1:4,1:2),P_x_z_pre(5:8,3:4),P_x_z_pre(9:12,5:6));

K_kalman=P_x_z/P_z_z;
X_out=X_pre+K_kalman*(Z_in-Z_pre);
P_out=P_pre-K_kalman*P_z_z*(K_kalman)';