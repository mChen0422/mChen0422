function A=getA
global observer;
global observerNum;
global r;  %传感器通信距离
% A=zeros(observerNum,observerNum);
% for i=1:observerNum
%         for j=1:observerNum
%             if j~=i
%         %如果k时刻i和j传感器可以相互通信
%          if sqrt((observer(i).trace(1,1)-observer(j).trace(1,1))^2+(observer(i).trace(1,2)-observer(j).trace(1,2))^2)<=r
%          A(i,j)=1;   %通信拓扑结构
%          else
%          A(i,j)=0;   
%          end
%          else
%          A(i,j)=0; 
%             end
%         end
% end
A=[0,1,0,0,0,0,0,0,0,0
    0,0,1,0,0,0,0,0,0,0
    0,0,0,1,0,0,0,0,0,0
    0,0,0,0,1,0,0,0,0,0
    0,0,0,0,0,1,0,0,0,0
    0,0,0,0,0,0,1,0,0,0
    0,0,0,0,0,0,0,1,0,0
    0,0,0,0,0,0,0,0,1,0
    0,0,0,0,0,0,0,0,0,1
    1,0,0,0,0,0,0,0,0,0];
    