clc;
clear all;
close all;
global r;
global targetNum;
global observerNum;
global observer;
global observer_max;
global observer_center;
global N;
targetNum=3; %目标数
observerNum=10; %传感器数目
r=800;%传感器通信距离
T=1;
L=100; %迭代次数
N=100/T;
monteNum=1; %蒙特卡洛仿真次数

%% 目标状态
target(1).state=zeros(4,N);
target(1).state(:,1)=[-200,-200,10,10]';
target(2).state=zeros(4,N);
target(2).state(:,1)=[-180,-200,10,10]';
target(3).state=zeros(4,N);
target(3).state(:,1)=[-190,-200,10,10]';
for i=1:targetNum

Q=0.05*eye(4);
w=-3*pi/180;
F= [1  0 sin(w*T)/w -(1-cos(w*T))/w
    0 1 (1-cos(w*T))/w -sin(w*T)/w
    0 0 cos(w*T)    -sin(w*T)
    0  0 sin(w*T)  cos(w*T) ]; %
for k=2:N
    target(i).state(:,k)=F*target(i).state(:,k-1)+sqrt(Q)*randn(4,1);
end
end
%% 传感器状态
initObserver;
for k=1:N
    for i=1:observerNum
        for j=1:targetNum
    %最大迹
    observer_max(i).xCKF((j-1)*4+1:j*4,k)=zeros(4,1);
    observer_max(i).PCKF((j-1)*4+1:j*4,(j-1)*4+1:j*4,k)=zeros(4,4);
    %M原则
    observer(i).xCKF((j-1)*4+1:j*4,k)=zeros(4,1);
    observer(i).PCKF((j-1)*4+1:j*4,(j-1)*4+1:j*4,k)=zeros(4,4);
    %集中式
    observer_center(i).xCKF((j-1)*4+1:j*4,k)=zeros(4,1);
    observer_center(i).PCKF((j-1)*4+1:j*4,(j-1)*4+1:j*4,k)=zeros(4,4);
        end
    end
end
x_monte=zeros(4*targetNum,N,monteNum); % 用于存储monte仿真的结果
x_monte_max=zeros(4*targetNum,N,monteNum);
x_monte_center=zeros(4*targetNum,N,monteNum);

%% 拓扑结构与权重矩阵
A=getA;
W=zeros(observerNum,observerNum);
for i=1:observerNum
    for j=1:observerNum
        if i~=j
            d_i=sum(A(i,:));
            d_j=sum(A(j,:));
            W(i,j)=1/(1+max(d_i,d_j))*A(i,j); % A(i,j)=1表示(i,j)属于E
        end
    end
    W(i,i)=1-sum(W(i,:));
end

for m=1:monteNum
waitbar(m/monteNum); %进度条


%% CKF滤波
%ckf初始化
for i=1:observerNum
observer(i).xCKF(:,1)=[target(1).state(:,1);target(2).state(:,1);target(3).state(:,1)];
P=diag([0.01,0.02,0.03,0.04]);
observer(i).PCKF(:,:,1)=blkdiag(P,P,P);
observer_max(i).xCKF(:,1)=[target(1).state(:,1);target(2).state(:,1);target(3).state(:,1)];
observer_max(i).PCKF(:,:,1)=blkdiag(P,P,P);
observer_center(i).xCKF(:,1)=[target(1).state(:,1);target(2).state(:,1);target(3).state(:,1)];
observer_center(i).PCKF(:,:,1)=blkdiag(P,P,P);
g(:,i,1)=[15*sin((i-1)*pi/5);15*cos((i-1)*pi/5);0;0];
U(:,i,1)=[0;0;0;0];
g_max(:,i,1)=[15*sin((i-1)*pi/5);15*cos((i-1)*pi/5);0;0];
U_max(:,i,1)=[0;0;0;0];
g_center(:,i,1)=[15*sin((i-1)*pi/5);15*cos((i-1)*pi/5);0;0];
U_center(:,i,1)=[0;0;0;0];

end
%
B=[0,1;
    -1,0;
    0,0;
    0,0];
K=[      0.0000    0.0550    0.0014   -0.0548
   -0.0550    0.0000   -0.0547   -0.0043];
% K=zeros(2,4);
for k=2:N
    k
    %% 多智能体编队跟踪控制并测量多目标
    for i=1:observerNum
        g(:,i,k)=[30*sin((i-1)*pi/5);30*cos((i-1)*pi/5);0;0];
        U(:,i,k)=zeros(4,1);
        g_max(:,i,k)=[30*sin((i-1)*pi/5);30*cos((i-1)*pi/5);0;0];
        U_max(:,i,k)=zeros(4,1);
        g_center(:,i,k)=[30*sin((i-1)*pi/5);30*cos((i-1)*pi/5);0;0];
        U_center(:,i,k)=zeros(4,1);
        for j=1:observerNum
        U(:,i,k)=U(:,i,k)+((observer(i).trace(k-1,:)'-g(:,i,k-1))-(observer(j).trace(k-1,:)'-g(:,j,k-1)));
        U_max(:,i,k)=U_max(:,i,k)+((observer_max(i).trace(k-1,:)'-g_max(:,i,k-1))-(observer_max(j).trace(k-1,:)'-g_max(:,j,k-1)));
        U_center(:,i,k)=U_center(:,i,k)+((observer_center(i).trace(k-1,:)'-g_center(:,i,k-1))-(observer_center(j).trace(k-1,:)'-g_center(:,j,k-1)));
        end
        for j=1:targetNum
        U(:,i,k)=U(:,i,k)+(observer(i).trace(k-1,:)'-g(:,i,k-1)-observer(i).xCKF(4*(j-1)+1:4*j,k-1));
        U_max(:,i,k)=U_max(:,i,k)+(observer_max(i).trace(k-1,:)'-g_max(:,i,k-1)-observer_max(i).xCKF(4*(j-1)+1:4*j,k-1));
        U_center(:,i,k)=U_center(:,i,k)+(observer_center(i).trace(k-1,:)'-g_center(:,i,k-1)-observer_center(i).xCKF(4*(j-1)+1:4*j,k-1));
        end
    end
    for i=1:observerNum
       observer(i).trace(k,:)=F*observer(i).trace(k-1,:)'+B*K*U(:,i,k);
       observer(i).trace(k,:)=observer(i).trace(k,:)';
       observer_max(i).trace(k,:)=F*observer_max(i).trace(k-1,:)'+B*K*U_max(:,i,k);
       observer_max(i).trace(k,:)=observer_max(i).trace(k,:)';
       observer_center(i).trace(k,:)=F*observer_center(i).trace(k-1,:)'+B*K*U_center(:,i,k);
       observer_center(i).trace(k,:)=observer_center(i).trace(k,:)';
     for j=1:targetNum
    %MT-CKF的测量值
    observer(i).measure((j-1)*2+1:j*2,k)=measure(target(j).state(:,k),observer(i).trace(k,:)')+sqrt(observer(i).R)*randn(2,1);
    observer_max(i).measure((j-1)*2+1:j*2,k)=measure(target(j).state(:,k),observer_max(i).trace(k,:)')+sqrt(observer_max(i).R)*randn(2,1);
    observer_center(i).measure((j-1)*2+1:j*2,k)=measure(target(j).state(:,k),observer_center(i).trace(k,:)')+sqrt(observer_center(i).R)*randn(2,1);
     end
    end
    %% 滤波
   for o=1:observerNum 
        [observer(o).xCKF(:,k),observer(o).PCKF(:,:,k)]=CKF(observer(o).xCKF(:,k-1),observer(o).PCKF(:,:,k-1),observer(o).measure(:,k),observer(o).R,observer(o).trace(k,:));
        [observer_max(o).xCKF(:,k),observer_max(o).PCKF(:,:,k)]=CKF(observer_max(o).xCKF(:,k-1),observer_max(o).PCKF(:,:,k-1),observer_max(o).measure(:,k),observer_max(o).R,observer_max(o).trace(k,:));
        [observer_center(o).xCKF(:,k),observer_center(o).PCKF(:,:,k)]=CKF(observer_center(o).xCKF(:,k-1),observer_center(o).PCKF(:,:,k-1),observer_center(o).measure(:,k),observer_center(o).R,observer_center(o).trace(k,:));
   end

   %% 分布式融合,M原则的权重矩阵
   for l=1:L
       for i=1:observerNum
          xCKF(:,i,l)=zeros(4*targetNum,1);
          PCKF(:,:,i)=zeros(4*targetNum,4*targetNum);
           for j=1:observerNum
          xCKF(:,i,l)=xCKF(:,i,l)+W(i,j)*observer(j).xCKF(:,k);
          PCKF(:,:,i)=PCKF(:,:,i)+W(i,j)*observer(j).PCKF(:,:,k);
           end  
       end
       for i=1:observerNum
        observer(i).xCKF(:,k)=xCKF(:,i,l);
        observer(i).PCKF(:,:,k)=PCKF(:,:,i);
       end
   end
x_monte(:,k,m)=observer(1).xCKF(:,k);
%% 分布式融合,最大迹的权重矩阵
   for l=1:L
       for i=1:observerNum
          xCKF_max(:,i,l)=zeros(4*targetNum,1);
          PCKF(:,:,i)=zeros(4*targetNum,4*targetNum);
          Psum=zeros(3,observerNum);
          WW=zeros(3,observerNum);
          for t=1:targetNum
             for j=1:observerNum
               Psum(t,j)=(trace(inv(observer_max(j).PCKF((t-1)*4+1:t*4,(t-1)*4+1:t*4,k)))+randn(1))*A(i,j);
             end
               Psum(t,i)=trace(inv(observer_max(i).PCKF((t-1)*4+1:t*4,(t-1)*4+1:t*4,k)))+randn(1);
               [MAX,index(j)]=max(Psum(t,:));
               WW(t,index(j))=1;
             for j=1:observerNum
               xCKF_max((t-1)*4+1:t*4,i,l)=xCKF_max((t-1)*4+1:t*4,i,l)+WW(t,j)*observer_max(j).xCKF((t-1)*4+1:t*4,k);
               PCKF((t-1)*4+1:t*4,(t-1)*4+1:t*4,i)=PCKF((t-1)*4+1:t*4,(t-1)*4+1:t*4,i)+...
                                                   WW(t,j)*observer_max(j).PCKF((t-1)*4+1:t*4,(t-1)*4+1:t*4,k);
             end  
          end
                 
       end

       for i=1:observerNum
        observer_max(i).xCKF(:,k)=xCKF_max(:,i,l);
        observer_max(i).PCKF(:,:,k)=PCKF(:,:,i);
       end
   end
   x_monte_max(:,k,m)=observer_max(1).xCKF(:,k);

   %% 集中式融合
   x_center=zeros(4*targetNum,1);
   P_center=zeros(4*targetNum,4*targetNum);
    for i=1:observerNum
      x_center(:,1)=x_center(:,1)+observer_center(i).xCKF(:,k)/observerNum;
      P_center(:,:)=P_center(:,:)+observer_center(i).PCKF(:,:,k)/observerNum;
    end
    for i=1:observerNum
        observer_center(i).xCKF(:,k)=x_center(:,1);
        observer_center(i).PCKF(:,:,k)=P_center(:,:);
    end
    x_monte_center(:,k,m)=observer_center(1).xCKF(:,k);
end
end
%% 误差RMSE,M原则的权重矩阵
MSE=zeros(1,N);
for m=1:monteNum
error=x_monte(:,:,m)-[target(1).state(:,:);target(2).state(:,:);target(3).state(:,:)];
  for k=1:N
    for i=1:targetNum
      MSE(1,k)=MSE(1,k)+error((i-1)*4+1,k)^2+error((i-1)*4+2,k)^2+error((i-1)*4+3,k)^2+error((i-1)*4+4,k)^2;
    end
  end
end
RMSE=(MSE/monteNum).^0.5;
%% 误差RMSE,最大迹的权重矩阵
MSE_max=zeros(1,N);
for m=1:monteNum
error_max=x_monte_max(:,:,m)-[target(1).state(:,:);target(2).state(:,:);target(3).state(:,:)];
  for k=1:N
    for i=1:targetNum
      MSE_max(1,k)=MSE_max(1,k)+error_max((i-1)*4+1,k)^2+error_max((i-1)*4+2,k)^2+error_max((i-1)*4+3,k)^2+error_max((i-1)*4+4,k)^2;
    end
  end
end
RMSE_max=(MSE_max/monteNum).^0.5;
%% 误差RMSE,集中式信息融合
MSE_center=zeros(1,N);
for m=1:monteNum
error_center=x_monte_center(:,:,m)-[target(1).state(:,:);target(2).state(:,:);target(3).state(:,:)];
  for k=1:N
    for i=1:targetNum
      MSE_center(1,k)=MSE_center(1,k)+error_center((i-1)*4+1,k)^2+error_center((i-1)*4+2,k)^2+error_center((i-1)*4+3,k)^2+error_center((i-1)*4+4,k)^2;
    end
  end
end
RMSE_center=(MSE_center/monteNum).^0.5;

figure(2)
plot(2:N,RMSE(1,2:N),'r');hold on
plot(2:N,RMSE_max(1,2:N),'b');hold on
plot(2:N,RMSE_center(1,2:N),'g');hold on
legend('MT-CKF-M with formation tracking','MT-CKF-max with formation tracking','MT-CKF-center with formation tracking');
xlabel('time (s)');ylabel('estimate errors (m)');
%% 目标运动和传感器跟踪
figure(1) 
plot(target(1).state(1,1:N),target(1).state(2,1:N),'o');hold on
plot(target(2).state(1,1:N),target(2).state(2,1:N),'*');hold on
plot(target(3).state(1,1:N),target(3).state(2,1:N),'+');hold on
legend('target1','target2','target3');
title('target state');
xlabel('x (m)'); ylabel('y (m)');

figure(3) 
plot(target(1).state(1,20),target(1).state(2,20),'o');hold on
plot(target(2).state(1,20),target(2).state(2,20),'o');hold on
plot(target(3).state(1,20),target(3).state(2,20),'o');hold on
% plot((observer(1).xCKF(1,59)+observer(1).xCKF(5,59)+observer(1).xCKF(9,59))/3,(observer(1).xCKF(2,59)+observer(1).xCKF(6,59)+observer(1).xCKF(10,59))/3,'+');hold on
plot((observer(1).xCKF(1,20)+observer(1).xCKF(5,20)+observer(1).xCKF(9,20))/3,(observer(1).xCKF(2,20)+observer(1).xCKF(6,20)+observer(1).xCKF(10,20))/3,'+');hold on
plot((target(1).state(1,20)+target(2).state(1,20)+target(3).state(1,20))/3,(target(1).state(2,20)+target(2).state(2,20)+target(3).state(2,20))/3,'*');hold on
% plot((observer(1).xCKF(1,61)+observer(1).xCKF(5,61)+observer(1).xCKF(9,61))/3,(observer(1).xCKF(2,61)+observer(1).xCKF(6,61)+observer(1).xCKF(10,61))/3,'+');hold on
% plot(observer(1).xCKF(5,1:N),observer(1).xCKF(6,1:N),'s');hold on
% plot(observer(1).xCKF(9,1:N),observer(1).xCKF(10,1:N),'s');hold on
plot(observer(1).trace(20,1),observer(1).trace(20,2),'s');hold on
plot(observer(2).trace(20,1),observer(2).trace(20,2),'s');hold on
plot(observer(3).trace(20,1),observer(3).trace(20,2),'s');hold on
plot(observer(4).trace(20,1),observer(4).trace(20,2),'s');hold on
plot(observer(5).trace(20,1),observer(5).trace(20,2),'s');hold on
plot(observer(6).trace(20,1),observer(6).trace(20,2),'s');hold on
plot(observer(7).trace(20,1),observer(7).trace(20,2),'s');hold on
plot(observer(8).trace(20,1),observer(8).trace(20,2),'s');hold on
plot(observer(9).trace(20,1),observer(9).trace(20,2),'s');hold on
plot(observer(10).trace(20,1),observer(10).trace(20,2),'s');hold on
% legend('target1','target2','target3','observer');
% title('target state');
xlabel('x (m)'); ylabel('y (m)');
for i=1:observerNum
for j=1:L
 a(i,j)=xCKF(1,i,j);
end
end
%  figure(7) 
% plot(target(1).state(1,40),target(1).state(2,40),'o');hold on
% plot(target(2).state(1,40),target(2).state(2,40),'o');hold on
% plot(target(3).state(1,40),target(3).state(2,40),'o');hold on
% % plot((observer(1).xCKF(1,59)+observer(1).xCKF(5,59)+observer(1).xCKF(9,59))/3,(observer(1).xCKF(2,59)+observer(1).xCKF(6,59)+observer(1).xCKF(10,59))/3,'+');hold on
% plot((observer(1).xCKF(1,40)+observer(1).xCKF(5,40)+observer(1).xCKF(9,40))/3,(observer(1).xCKF(2,40)+observer(1).xCKF(6,40)+observer(1).xCKF(10,40))/3,'+');hold on
% plot((target(1).state(1,40)+target(2).state(1,40)+target(3).state(1,40))/3,(target(1).state(2,40)+target(2).state(2,40)+target(3).state(2,40))/3,'*');hold on
% % plot((observer(1).xCKF(1,61)+observer(1).xCKF(5,61)+observer(1).xCKF(9,61))/3,(observer(1).xCKF(2,61)+observer(1).xCKF(6,61)+observer(1).xCKF(10,61))/3,'+');hold on
% % plot(observer(1).xCKF(5,1:N),observer(1).xCKF(6,1:N),'s');hold on
% % plot(observer(1).xCKF(9,1:N),observer(1).xCKF(10,1:N),'s');hold on
% plot(observer(1).trace(40,1),observer(1).trace(40,2),'s');hold on
% plot(observer(2).trace(40,1),observer(2).trace(40,2),'s');hold on
% plot(observer(3).trace(40,1),observer(3).trace(40,2),'s');hold on
% plot(observer(4).trace(40,1),observer(4).trace(40,2),'s');hold on
% plot(observer(5).trace(40,1),observer(5).trace(40,2),'s');hold on
% plot(observer(6).trace(40,1),observer(6).trace(40,2),'s');hold on
% plot(observer(7).trace(40,1),observer(7).trace(40,2),'s');hold on
% plot(observer(8).trace(40,1),observer(8).trace(40,2),'s');hold on
% plot(observer(9).trace(40,1),observer(9).trace(40,2),'s');hold on
% plot(observer(10).trace(40,1),observer(10).trace(40,2),'s');hold on
% % legend('target1','target2','target3','observer');
% % title('target state');
% xlabel('x (m)'); ylabel('y (m)');
% for i=1:observerNum
% for j=1:L
%  a(i,j)=xCKF(1,i,j);
% end
% end
% figure(8) 
% plot(target(1).state(1,60),target(1).state(2,60),'o');hold on
% plot(target(2).state(1,60),target(2).state(2,60),'o');hold on
% plot(target(3).state(1,60),target(3).state(2,60),'o');hold on
% % plot((observer(1).xCKF(1,59)+observer(1).xCKF(5,59)+observer(1).xCKF(9,59))/3,(observer(1).xCKF(2,59)+observer(1).xCKF(6,59)+observer(1).xCKF(10,59))/3,'+');hold on
% plot((observer(1).xCKF(1,60)+observer(1).xCKF(5,60)+observer(1).xCKF(9,60))/3,(observer(1).xCKF(2,60)+observer(1).xCKF(6,60)+observer(1).xCKF(10,60))/3,'+');hold on
% plot((target(1).state(1,60)+target(2).state(1,60)+target(3).state(1,60))/3,(target(1).state(2,60)+target(2).state(2,60)+target(3).state(2,60))/3,'*');hold on
% % plot((observer(1).xCKF(1,61)+observer(1).xCKF(5,61)+observer(1).xCKF(9,61))/3,(observer(1).xCKF(2,61)+observer(1).xCKF(6,61)+observer(1).xCKF(10,61))/3,'+');hold on
% % plot(observer(1).xCKF(5,1:N),observer(1).xCKF(6,1:N),'s');hold on
% % plot(observer(1).xCKF(9,1:N),observer(1).xCKF(10,1:N),'s');hold on
% plot(observer(1).trace(60,1),observer(1).trace(60,2),'s');hold on
% plot(observer(2).trace(60,1),observer(2).trace(60,2),'s');hold on
% plot(observer(3).trace(60,1),observer(3).trace(60,2),'s');hold on
% plot(observer(4).trace(60,1),observer(4).trace(60,2),'s');hold on
% plot(observer(5).trace(60,1),observer(5).trace(60,2),'s');hold on
% plot(observer(6).trace(60,1),observer(6).trace(60,2),'s');hold on
% plot(observer(7).trace(60,1),observer(7).trace(60,2),'s');hold on
% plot(observer(8).trace(60,1),observer(8).trace(60,2),'s');hold on
% plot(observer(9).trace(60,1),observer(9).trace(60,2),'s');hold on
% plot(observer(10).trace(60,1),observer(10).trace(60,2),'s');hold on
% % legend('target1','target2','target3','observer');
% % title('target state');
% xlabel('x (m)'); ylabel('y (m)');
% for i=1:observerNum
% for j=1:L
%  a(i,j)=xCKF(1,i,j);
% end
% end
% figure(9) 
% plot(target(1).state(1,80),target(1).state(2,80),'o');hold on
% plot(target(2).state(1,80),target(2).state(2,80),'o');hold on
% plot(target(3).state(1,80),target(3).state(2,80),'o');hold on
% % plot((observer(1).xCKF(1,59)+observer(1).xCKF(5,59)+observer(1).xCKF(9,59))/3,(observer(1).xCKF(2,59)+observer(1).xCKF(6,59)+observer(1).xCKF(10,59))/3,'+');hold on
% plot((observer(1).xCKF(1,80)+observer(1).xCKF(5,80)+observer(1).xCKF(9,80))/3,(observer(1).xCKF(2,80)+observer(1).xCKF(6,80)+observer(1).xCKF(10,80))/3,'+');hold on
% plot((target(1).state(1,80)+target(2).state(1,80)+target(3).state(1,80))/3,(target(1).state(2,80)+target(2).state(2,80)+target(3).state(2,80))/3,'*');hold on
% % plot((observer(1).xCKF(1,61)+observer(1).xCKF(5,61)+observer(1).xCKF(9,61))/3,(observer(1).xCKF(2,61)+observer(1).xCKF(6,61)+observer(1).xCKF(10,61))/3,'+');hold on
% % plot(observer(1).xCKF(5,1:N),observer(1).xCKF(6,1:N),'s');hold on
% % plot(observer(1).xCKF(9,1:N),observer(1).xCKF(10,1:N),'s');hold on
% plot(observer(1).trace(80,1),observer(1).trace(80,2),'s');hold on
% plot(observer(2).trace(80,1),observer(2).trace(80,2),'s');hold on
% plot(observer(3).trace(80,1),observer(3).trace(80,2),'s');hold on
% plot(observer(4).trace(80,1),observer(4).trace(80,2),'s');hold on
% plot(observer(5).trace(80,1),observer(5).trace(80,2),'s');hold on
% plot(observer(6).trace(80,1),observer(6).trace(80,2),'s');hold on
% plot(observer(7).trace(80,1),observer(7).trace(80,2),'s');hold on
% plot(observer(8).trace(80,1),observer(8).trace(80,2),'s');hold on
% plot(observer(9).trace(80,1),observer(9).trace(80,2),'s');hold on
% plot(observer(10).trace(80,1),observer(10).trace(80,2),'s');hold on
% % legend('target1','target2','target3','observer');
% % title('target state');
% xlabel('x (m)'); ylabel('y (m)');
for i=1:observerNum
for j=1:L
 a(i,j)=xCKF(1,i,j);
end
end
figure(4)
for i=1:observerNum
 plot(1:L,a(i,1:L),'r');hold on;
end
xlabel('consensus step');ylabel('estimate (m)');
for i=1:observerNum
for j=1:L
 b(i,j)=sum(xCKF(:,i,j)-[target(1).state(:,N);target(2).state(:,N);target(3).state(:,N)],1);
end
end
figure(5)
for i=1:observerNum
 plot(1:L,b(i,1:L),'r');hold on;
end
xlabel('consensus step');ylabel('estimate errors (m)');
figure(6)
for j=1:observerNum
for i=1:N
p(1:4,i,j)=observer(j).trace(i,:)'-g(:,j,i)-(target(1).state(:,i)+target(2).state(:,i)+target(3).state(:,i))/3;
p(5,i,j)=dot(p(1:4,i,j),p(1:4,i,j));
end
plot(1:N,p(5,1:N,j));hold on
end
legend('c=1','c=2','c=3','c=4','c=5','c=6','c=7','c=8','c=9','c=10');
xlabel('time (s)');ylabel('formation tracking errors (m)');