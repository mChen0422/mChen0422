function initObserver
global observer;
global observer_max;
global observer_center;
global targetNum;
global observerNum;
global N; 

%% 初始化传感器均匀分布
for i=1:observerNum
    observer(i).trace(1,:)=[-150,-150,10,10]; % 观测器i的运动轨迹
    observer(i).type=1; % 雷达传感器
    observer_max(i).trace(1,:)=[-150,-150,10,10]; % 观测器i的运动轨迹
    observer_max(i).type=1; % 雷达传感器
    observer_center(i).trace(1,:)=[-150,-150,10,10]; % 观测器i的运动轨迹
    observer_center(i).type=1; % 雷达传感器
end
for i=2:2:observerNum
    observer(i).type=2; % 红外传感器
    observer_max(i).type=2; % 红外传感器
    observer_center(i).type=2; % 红外传感器
end
% figure(1)
% for i=1:observerNum
%     if observer(i).type==1
%     plot(observer(i).trace(1,1),observer(i).trace(1,2),'ko');hold on;
%     else
%     plot(observer(i).trace(1,1),observer(i).trace(1,2),'ks');hold on;    
%     end
% end


%% 初始化传感器测量噪声R
 R1=diag([1,1*pi/180]);  %雷达协方差
R1=R1*R1;
 R2=diag([1,0.2*pi/180]);  %红外协方差
R2=R2*R2;
for i=1:observerNum
    if observer(i).type==1
    observer(i).R=R1;
    observer_max(i).R=R1;
    observer_center(i).R=R1;
    else
    observer(i).R=R2;   
    observer_max(i).R=R2;
    observer_center(i).R=R2;    
    end
end
%% 初始化传感器测量
for i=1:observerNum
    observer(i).measure=zeros(2*targetNum,N);
    observer_max(i).measure=zeros(2*targetNum,N);
    observer_center(i).measure=zeros(2*targetNum,N);
end

end


