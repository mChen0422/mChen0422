%% 观测
function z=measure(X1,X2)
d=sqrt((X1(1)-X2(1))^2+(X1(2)-X2(2))^2);
if X1(2,1)-X2(2,1)>0
    if X1(1,1)-X2(1,1)>0
        thita=atan(abs((X1(2,1)-X2(2,1))/X1(1,1)-X2(1,1)));
    elseif X1(1,1)-X2(1,1)==0
        thita=pi/2;
    else
        thita=pi/2+atan(abs((X1(2,1)-X2(2,1))/X1(1,1)-X2(1,1)));
    end
elseif X1(2,1)-X2(2,1)<0
    if X1(1,1)-X2(1,1)>0
        thita=3*pi/2+atan(abs((X1(2,1)-X2(2,1))/X1(1,1)-X2(1,1)));
    elseif X1(1,1)-X2(1,1)==0
        thita=3*pi/2;
    else
       thita=pi+atan(abs((X1(2,1)-X2(2,1))/X1(1,1)-X2(1,1))); 
    end
else
    if X1(1,1)-X2(1,1)>0
        thita=0;
    else
        thita=pi;
    end
end
z=[d;thita];
end