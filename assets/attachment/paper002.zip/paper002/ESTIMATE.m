function x=ESTIMATE(x_filter)
x=[];
for i=1:x_filter.J
    if x_filter.w(i)>0.5
        for j=1:round(x_filter.w(i))
            x=[x,x_filter.m(:,i)];
        end
    end
end
%================��ͼ================
a=size(x,2);
figure(1)
if a~=0
    plot(x(1,:),x(3,:),'.'),hold on
end