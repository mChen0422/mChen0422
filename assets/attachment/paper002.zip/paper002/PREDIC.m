function  x_predic=PREDIC(x_filter,F,ps,birth,q_noise,G)
%======================����Ŀ��Ԥ��=========================
x_birth=birth;
%======================���Ŀ��Ԥ��=========================
x_survival=PREDIC_S(x_filter,F,ps,q_noise,G);
%========================================================
x_predic.m=[x_birth.m,x_survival.m];
x_predic.P=cat(3,x_birth.P,x_survival.P);
x_predic.w=[x_birth.w,x_survival.w];
x_predic.J=x_birth.J+x_survival.J;
