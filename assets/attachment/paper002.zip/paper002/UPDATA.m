function x_filter=UPDATA(x_predic,Y,pd,H,R,r)
%===================��©��Ŀ�����======================
w=(1-pd).*x_predic.w;
m=x_predic.m;
P=x_predic.P;
%===================����ʵĿ�����======================

for s=1:Y.n
    w1=[];
    for j=1:x_predic.J
        y=H*x_predic.m(:,j);
        S=R+H*x_predic.P(:,:,j)*H';
        e=exp(-0.5*(Y.m(:,s)-y)'*inv(S)*(Y.m(:,s)-y));
        w1=[w1 pd*x_predic.w(j)*e];
        
        K=x_predic.P(:,:,j)*H'*inv(S);
        m1=x_predic.m(:,j)+K*(Y.m(:,s)-y);
        m=[m,m1];
        P1=x_predic.P(:,:,j)-K*H*x_predic.P(:,:,j);
        P=cat(3,P,P1);
    end
    K=r/200^2;          %�Ӳ�ǿ��
    w2=sum(w1);
    w1=w1/(K+w2);
    w=[w,w1];
end
x_filter.m=m;
x_filter.P=P;
x_filter.w=w;
x_filter.J=(1+s)*x_predic.J;
    
            
            