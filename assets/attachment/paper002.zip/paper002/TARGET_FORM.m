function target_position=TARGET_FORM(F,G,q_noise)  
target_position.m(1).s=[];
target_position.m(2).s=[];
target_position.m(3).s=[];
target_position.m(4).s=[];
target_position.n=zeros(4,100);
% target_position.n(2,6:100)=1;
% target_position.n(3,11:100)=1;
% target_position.n(4,16:100)=1;
target_position.n(1,1:100)=1;
target_position.n(2,1:100)=1;
target_position.n(3,1:100)=1;
target_position.n(4,1:100)=1;
%================Ŀ��1�˶��켣===================
u=[200,-1,200,-1]';
target_position.m(1).s=u;
for i=2:100
    u=F*u+G*(q_noise.*randn(2,1));%randn(2,1)��׼��̬�ֲ�
    target_position.m(1).s=[target_position.m(1).s,u];
end
%================Ŀ��2�˶��켣===================
u=[200,-1,-200,1]';
% u=target_position.m(1).s(:,10);
target_position.m(2).s=u;
for i=11:100
    u=F*u+G*(q_noise.*randn(2,1));
    target_position.m(2).s=[target_position.m(2).s,u];
end
%================Ŀ��3�˶��켣===================
u=[-200,1,200,-1]';
target_position.m(3).s=u;
for i=2:100
    u=F*u+G*(q_noise.*randn(2,1));
    target_position.m(3).s=[target_position.m(3).s,u];
end
%================Ŀ��4�˶��켣===================
u=[-200,1,-200,1]';
target_position.m(4).s=u;
for i=2:100
    u=F*u+G*(q_noise.*randn(2,1));
    target_position.m(4).s=[target_position.m(4).s,u];
end

%===============����Ŀ���˶��켣=================
figure(1)
plot(target_position.m(1).s(1,:),target_position.m(1).s(3,:),'b'),hold on
plot(target_position.m(2).s(1,:),target_position.m(2).s(3,:),'r'),hold on
plot(target_position.m(3).s(1,:),target_position.m(3).s(3,:),'g'),hold on
plot(target_position.m(4).s(1,:),target_position.m(4).s(3,:),'k'),hold on

title('目标状态')
xlabel('x/m'),ylabel('y/m')


