%author:Qi Jialin

clear all
clc,close all
tic;

%===============初始参数设定===============
T=1;                                                           %采样时间间隔
N=100;                                                          %测量时间
M_number=1;                                                    %程序运行次数
     Msample=500;                                                   %粒子数目
     x_number=zeros(1,N);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
     x_number(1)=1;                                                 %目标的初始个数
q_noise1=0.5;                                                  %状态噪声方差
q_noise2=0.1;                                                  %状态噪声方差
q_noise=[q_noise1;q_noise2];           
%     T_prun=1e-7;                                                   %修剪门限  7|2|270/200
%     U_merg=1;                                                      %合并门限
%     UU_merg=50;                                                      %融合时的合并门限
%     J_max=300;                                                     %最大高斯数
    c_ospa=150;
    p_ospa=2;
F=[1,T,0,0
   0,1,0,0
   0,0,1,T
   0,0,0,1];                                                   %存活目标转移矩阵
G=[T^2/2,0
    T,0
    0,T^2/2
    0,T];                                                      %状态噪声的转移矩阵
Cons=[1,1,1,0                                                  %传感器拓扑
    1,1,0,1
    1,0,1,1
    0,1,1,1];                                                     
%===================目标的真实运动轨迹====================
target_position=TARGET_FORM(F,G,q_noise);                      %目标的真实运动轨�?
target_position.m(2).s=[zeros(4,10),target_position.m(2).s];
target_position.m(3).s=[zeros(4,30),target_position.m(3).s];
% target_position.m(4).s=[zeros(4,15),target_position.m(4).s];
target_position.n(2,1:10)=0;
target_position.n(3,1:30)=0;
% target_position.n(4,1:15)=0;

%====================存活目标初始化=======================
% initial.m(:,1)=target_position.m(1).s(:,1);
for i=1:4
    initial.m(:,i)=target_position.m(i).s(:,1);   %目标的初始位置
    initial.w(i)=1;
end
% Q_noise=[q_noise1^2,0
%          0,q_noise2^2];
Q=G*diag([q_noise(1),q_noise(2)])*G';
initial.P=diag([1 2 1 2]);             %目标的初始协方差矩阵
initial.P=cat(4,initial.P,initial.P,initial.P,initial.P);
% initial.w=0.8;
initial.J=4;
%====================新生目标初始化=======================
birth.m(:,1)=[-200,1,200,-1]';                                     %birth对应于目标出现强度函数
birth.m(:,2)=[200,-1,-200,1]';
birth.P=diag([1 2 1 2]);
birth.P=cat(3,birth.P,birth.P); %构造三维数组  
birth.w(1)=0.8;
birth.w(2)=0.8;
birth.J=2;                                                   %新生目标高斯分量数
%======================生成量测报告========================
H=[1,0,0,0
   0,0,1,0];                                                   %量测矩阵
r_noise=[0.5;0.5];                                             %量测噪声标准差
R=[r_noise(1)^2,0
    0,r_noise(2)^2];
ps=0.99;                                                       %目标存活概率
pd=0.98;                                                       %目标检测概率
r=3;                                                           %每时刻杂波点平均数
motocaro_number=2;                                            %蒙特卡罗次数
x_number=zeros(motocaro_number,N);                             %PHD估计的目标数目
x_number_e=zeros(motocaro_number,N);                      %平滑后 估计的目标数目
% dh1=zeros(motocaro_number,N);  
% dw1=zeros(motocaro_number,N);
d_ospa1=zeros(motocaro_number,N);
% dhe=zeros(motocaro_number,N);
% dwe=zeros(motocaro_number,N);
d_ospae=zeros(motocaro_number,N);
epos=cell(motocaro_number,N);
epose=cell(motocaro_number,N);
er=0;                                                        %事件触发门槛
Sum1=0;                                                         %未加事件触发前的计算数目
Save=0;                                                        %事件触发节省的计算数目
Sum2=0;                                                       %事件触发后的计算数目
eSum=zeros(motocaro_number,N);                                               %事件触发的具体情况
for kk=1:motocaro_number
    str=[num2str(kk),'/',num2str(motocaro_number)];  %number to string 第几次蒙特卡洛仿真
    disp(str);
    clear x x_filter  x_predict 
    
for L=1:4    
Y_measure.q(L).p=MEASUREMENT(H,r_noise,target_position,N,pd,r);       %产生4个传感器的测量数据
end
%======================目标随机集====================================
for i=1:100
    x(i).m=[];
    for j=1:4
        if target_position.n(j,i)==1
            x(i).m=[x(i).m,target_position.m(j).s(:,i)];
        end
    end
end
%==========================================================
%                         主程序
%==========================================================
    T_prun=1e-7;                                                   %修剪门限  7|2|270/200
    TT_prun=1e-3;
    U_merg=1;                                                      %合并门限
    UU_merg=50;                                                      %融合时的合并门限
    J_max=300;                                                     %最大高斯数
    JJ_max=300;
number_sensor=size(Cons,1);  %传感器数目
for L=1:number_sensor
x_filter_phd.a(L)=initial;
end
% 
for i=2:N
 for L=1:number_sensor
    Sum1=Sum1+1;      %未加事件触发前的计算数目
    x_predic_phd.a(L)=PREDIC(x_filter_phd.a(L),F,ps,birth,q_noise,G);%目标预测
    x_filter_phd.a(L)=UPDATA(x_predic_phd.a(L),Y_measure.q(L).p(i),pd,H,R,r);    %目标更新
    x_filter_phd1.a(L)=x_filter_phd.a(L);
    x_filter_phd.a(L)=PRUN_MERG(x_filter_phd.a(L),T_prun,U_merg,J_max);    %修剪合并高斯项
    x_filter_phd1.a(L)=x_filter_phd.a(L);
 end
%==================传感器融合=================
    for C=1:1        %传感器融合次数C=7
        for s=1:number_sensor
             D.a(s).m=[];D.a(s).P=[];D.a(s).w=[];D.a(s).n=0;
        end
    for p=1:number_sensor
    for q=1:number_sensor
        if Cons(p,q)==1
        D.a(p).m=[D.a(p).m,x_filter_phd1.a(q).m];
        D.a(p).P=cat(3,D.a(p).P,x_filter_phd1.a(q).P);
        D.a(p).w=[D.a(p).w,x_filter_phd1.a(q).w];
        D.a(p).n=D.a(p).n+x_filter_phd1.a(q).J;
        end
    end
    end   
   % ==================传感器融合后合并=================
    for p=1:number_sensor
    x_filter_phd1.a(p)=MERG(D.a(p),TT_prun,UU_merg,JJ_max);    %合并高斯项
    end
    end
    
    for p=1:number_sensor
     x_number(kk,i)=x_number(kk,i)+(1/number_sensor)*round(sum(x_filter_phd1.a(p).w));    %估计目标数目
    x_estimate1=ESTIMATE(x_filter_phd1.a(p));    %目标状态估计
    epos{kk,i}=x_estimate1;              %存储估计的状态
            if (~isempty(x(i).m)) && (~isempty(x_estimate1)) %误差分析
            d_ospa1(kk,i)=d_ospa1(kk,i)+(1/number_sensor)*OSPA(x(i).m,x_estimate1,c_ospa,p_ospa);  %OSPA
            end
    end
end

    T_prun=1e-7;                                                   %修剪门限  7|2|270/200
    TT_prun=1e-3;
    U_merg=1;                                                      %合并门限
    UU_merg=1000;                                                      %融合时的合并门限
    J_max=300;                                                     %最大高斯数
    JJ_max=300;

    
for L=1:number_sensor
x_filter_phd.a(L)=initial;
end
% x_filter=cell(1,N);  %1行N列的元胞数组
% x_filter{1}=initial;
% x_predic=cell(1,N);
j=ones(1,4);
for i=2:N
 for L=1:number_sensor
   % i时间和j时间测量值x,y绝对值和的差的绝对值之和
   %  Y_measure(i).c=((Y_measure(i).s(1)-Y_measure(j).s(1))^2+(Y_measure(i).s(2)-Y_measure(j).s(2))^2)^0.5;
   %事件触发机制300-10% 400-20% 500-30%   600-40%
  % i时间和j时间测量值z的差的矩阵乘z的差矩阵的转置
   u=Y_measure.q(L).p(i).n-size(Y_measure.q(L).p(j(L)).m,2);
   Q=zeros(2,abs(u));
   if u>0 
     Y_measure.q(L).p(j(L)).m=[Y_measure.q(L).p(j(L)).m,Q];
   elseif u<0
     Y_measure.q(L).p(i).m=[Y_measure.q(L).p(i).m,Q];
   end
   Y_measure.q(L).p(i).c=Y_measure.q(L).p(i).m-Y_measure.q(L).p(j(L)).m;
   Y_measure.q(L).p(i).v=Y_measure.q(L).p(i).c*(Y_measure.q(L).p(i).c)';
    if Y_measure.q(L).p(i).v(1)/10^5>4&&Y_measure.q(L).p(i).v(4)/10^5>4%4&&4 12%;   5& 5 15%  7 1 300 3.5\3.5 25%  7 1 1000 300 300 5 540%
         Sum2=Sum2+1;   eSum(kk,i)=eSum(kk,i)+1/4; T=0;j(L)=i;  %最新一次的触发时间
         x_predic_phd.a(L)=PREDIC(x_filter_phd.a(L),F,ps,birth,q_noise,G);%目标预测
         x_filter_phd.a(L)=UPDATA(x_predic_phd.a(L),Y_measure.q(L).p(i),pd,H,R,r);    %目标更新
    else 
         Save=Save+1;eSum(kk,i)=eSum(kk,i)+0; T=T+1;
         x_predic_phd.a(L)=PREDIC(x_filter_phd.a(L),F,ps,birth,q_noise,G);%目标预测
         x_filter_phd.a(L)=UPDATA(x_predic_phd.a(L),Y_measure.q(L).p(j(L)),pd,H,R,r);    %目标更新

    end   
      x_filter_phd.a(L)=PRUN_MERG(x_filter_phd.a(L),T_prun,U_merg,J_max);    %修剪合并高斯项
      x_filter_phde.a(L)=x_filter_phd.a(L);
 end
% % ==================传感器融合=================
      for C=1:1       %传感器融合次数C=7
        for s=1:number_sensor
             I.a(s).m=[];I.a(s).P=[];I.a(s).w=[];m=[];P=[];w=[];I.a(s).n=0;
        end
    for p=1:number_sensor
    for q=1:number_sensor
        if Cons(p,q)==1
        I.a(p).m=[I.a(p).m,x_filter_phde.a(q).m];
        I.a(p).P=cat(3,I.a(p).P,x_filter_phde.a(q).P);
        I.a(p).w=[I.a(p).w,x_filter_phde.a(q).w];
        I.a(p).n=I.a(p).n+x_filter_phde.a(q).J;
        end
    end
    end   
%     ==================传感器融合后合并=================
    for p=1:number_sensor
    x_filter_phde.a(p)=MERG(I.a(p),TT_prun,UU_merg,J_max);    %合并高斯项
    end
      end
    
    for p=1:number_sensor
     x_number_e(kk,i)=x_number_e(kk,i)+(1/number_sensor)*round(sum(x_filter_phde.a(p).w));    %估计目标数目
    x_estimate=ESTIMATE(x_filter_phde.a(p));    %目标状态估计
    epose{kk,i}=x_estimate ;             %存储估计的状态
            if (~isempty(x(i).m)) && (~isempty(x_estimate)) %误差分析
            d_ospae(kk,i)=d_ospae(kk,i)+(1/number_sensor)*OSPA(x(i).m,x_estimate,c_ospa,p_ospa);  %OSPA
            end
    end
    end
end


esum=mean(eSum);
sss=ones(1,N);
sss=sss.*(sum(esum)/100);
x_numberm=mean(x_number);
x_number_stdm=std(x_number); %每一列标准差
x_numbers=mean(x_number_e);
x_number_stds=std(x_number_e);
number=sum(target_position.n);
mean_d_ospa1=mean(d_ospa1);
mean_d_ospae=mean(d_ospae); %每列平均值


toc;

figure(3)
plot(number,'g'),hold on
plot(x_numberm,'--'),hold on
plot(x_numbers,'-*'),hold on
legend('真实目标数目','GM-PHD计算目标数目','节省10%数据传输GM-PHD计算目标数目')
xlabel('时间/s'),ylabel('目标数目')
axis([0 100 0 5]);
figure(4)
plot(mean_d_ospa1,'-k'),hold on
plot(mean_d_ospae,'--m'),hold on
xlabel('时间/s'),ylabel('OSPA距离')
legend('GM-PHD计算OSPA距离','节省10%数据传输GM-PHD计算OSPA距离')

figure(5)
plot(1:N,esum,'-m'),hold on
plot(1:N,sss,'--m'),hold on
legend('10%ER-GM-PHD number','10%Average rate')
xlabel('Times(s)'),ylabel('Average triggering rate')
fprintf('原计算数目为：%d\n',Sum1);
fprintf('加事件触发计算数目为：%d\n',Sum2);
fprintf('加事件触发后节省：%d\n',Save);
fprintf('节省计算量：%f\n',Save/Sum1);

% figure(4)
% legend('40%ER-GM-PHD OSPA Distance','30%ER-GM-PHD OSPA Distance','20%ER-GM-PHD OSPA Distance','GM-PHD OSPA Distance','10%ER-GM-PHD OSPA Distance')
% figure(5)
% legend('40%ER-GM-PHD number','40%Average rate','30%ER-GM-PHD number','30%Average rate','20%ER-GM-PHD number','20%Average rate','10%ER-GM-PHD number','10%Average rate')
% figure(3)
% legend('true number','GM-PHD number','10%ER-GM-PHD number','40%ER-GM-PHD number','30%ER-GM-PHD number','20%ER-GM-PHD number')