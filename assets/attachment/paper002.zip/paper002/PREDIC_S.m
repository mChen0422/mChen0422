function x_survival=PREDIC_S(x_filter,F,ps,q_noise,G)
q=diag([q_noise(1),q_noise(2)]);
x_survival.m=[];
x_survival.P=[];
x_survival.w=[];
x_survival.J=x_filter.J;
for i=1:x_filter.J
    x=F*x_filter.m(:,i);
    w=ps*x_filter.w(i);
    P=F*x_filter.P(:,:,i)*F'+G*q*G';
    x_survival.m=[x_survival.m,x];
    x_survival.P=cat(3,x_survival.P,P);
    x_survival.w=[x_survival.w,w];
end